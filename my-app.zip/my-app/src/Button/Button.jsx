import react from 'react';
import style from "./button.module.css";

const Button = () => {

    console.log(style);

    return <button id={style.tbtn}>Click</button>

};

export default Button;


















