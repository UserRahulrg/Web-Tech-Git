const eledarkmode = document.getElementById('darkmode');
const elelightMode = document.getElementById('lightmode');
var eleheadermain;

function darkModeFunct(){
    eledarkmode.addEventListener("click",()=>{

        eleheadermain = document.querySelector('headerMain');
        eleheadermain.style.backgroundColor="black";
        eleheadermain.style.color="white";
    })
}

function lightModeFunct(){

    
}