var elesidebarnav = document.getElementById('sidebarnav');

var elesidebarnavclick = document.querySelector('nav-bar');
elesidebarnav.addEventListener("click",()=>{
    elesidebarnavclick.style.display="flex";
})
