alert("javascript is enabled!")

var x = 100;
var y = 20;

var sum;
var subtract;
var multiply;
var divide;
var approx;

sum = x + y;
alert("sum is :"+sum)
subtract = x - y;
alert("subtracted value is :"+subtract)
multiply = x * y;
alert("multiplied value is :"+multiply)
divide = x / y;
alert("divided value is :"+divide);
if(x > y){approx = x - y}else{approx = y - x}
alert("approx value is : "+approx);







