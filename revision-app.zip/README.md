# ReactBasics
This repository contain a React app - "my-app" with all basic/fundamental concepts of React.
