<html>
    <header>

    </header>

    <body>
        <head>
            
        </head>
        <form action="payscript.php" method="post">
            <div class="formcheckout">
            <label for="fname">Full Name</label>
            <input type="text" id="name" name="name">
            <label for="hidden">none</label>
            <input type="hidden" id="name" name="name">
            <label for="hidden">none</label>
            <input type="hidden" id="name" name="name">
            <label for="adr">Address</label>
            <input type="text" id="name" name="name">
            <label for="">None</label>
            <input type="hidden" id="name" name="name">
            </div>
            <input type="submit" value="Pay Now" class="btn">
        </form>

        <footer>

        </footer>
    </body>
</html>