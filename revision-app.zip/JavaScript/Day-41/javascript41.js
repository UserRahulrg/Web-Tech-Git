const arr = [1,2,3,4,5,6]

arr.forEach ((val,i,arry)=>{
    arry[i] = Math.pow(val);
})

console.log(arr);














