const acc = document.getElementById(".accordionTab");

acc.addEventListener("click",()=>{
    const cross = document.querySelector('.accord1')
    cross.classList.toggle("show")
})

const actionbtn1 = document.getElementById('p');
const actionbtn2 = document.getElementById('btnclick1')


actionbtn1.addEventListener("click",()=>{
    btnclick1.style.appearance.hidden;
})







