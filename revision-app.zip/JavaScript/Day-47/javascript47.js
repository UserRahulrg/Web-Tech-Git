const button = document.querySelector("button");

button.addEventListener("contentmenu",(e)=>{
    e.preventdefault();

    console.log("Button Right Clicked!!");
})

















































