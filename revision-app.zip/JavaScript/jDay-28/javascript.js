let age = 18;

if(!(age==20)){
    console.log("Eligible to Vote!!");
}
else{
    console.log("Not Eligible to Vote!!");

}
  



