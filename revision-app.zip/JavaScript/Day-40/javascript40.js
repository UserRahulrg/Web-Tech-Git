const arr = [10,20,30,40,50,60,null,undefined];

console.log(arr[0]);
console.log(arr[1]);
console.log(arr[2]);
console.log(arr[6]);
console.log(arr[7]);

const arra = new Array(10,20,30,40,50);
console.log(arra);



















