alert("Javascript is Linked!!");

var Username = "Lokesh";

alert("${Username}"+Username);











