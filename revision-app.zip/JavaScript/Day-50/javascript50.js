// const box = document.getElementById("box");
// let lSide = 100;
// let tSide = 100;

// window.addEventListener("keydown",(e)=> {
//     let move =50;
//     switch(e.key){
//         case "w":
//             tSide =tSide-move;
//             break;
//         case "s":
//             tSide =tSide-move;
//             break;
//         case "a":
//             tSide =tSide-move;
//             break;
//         case "d":
//             tSide =tSide-move;
//             break;
//         default:
//             break;
//     }
//     box.style.left=lSide+"px"
//     box.style.top=tSide+"px"

// })

// const box1 = document.getElementById("box");
// let lSide1 = 100;
// let tSide1 = 100;

// window.addEventListener("keydown",(e)=> {
//     let move =50;
//     switch(e.key){
//         case "w":
//             tSide =tSide-move;
//             break;
//         case "s":
//             tSide =tSide-move;
//             break;
//         case "a":
//             tSide =tSide-move;
//             break;
//         case "d":
//             tSide =tSide-move;
//             break;
//         default:
//             break;
//     }
//     box.style.left=lSide+"px"
//     box.style.top=tSide+"px"

// })

// const box2 = document.getElementById("box");
// let lSide2 = 100;
// let tSide2 = 100;

// window.addEventListener("keydown",(e)=> {
//     let move =50;
//     switch(e.key){
//         case "w":
//             tSide =tSide-move;
//             break;
//         case "s":
//             tSide =tSide-move;
//             break;
//         case "a":
//             tSide =tSide-move;
//             break;
//         case "d":
//             tSide =tSide-move;
//             break;
//         default:
//             break;
//     }
//     box.style.left=lSide+"px"
//     box.style.top=tSide+"px"

// })

// const box3 = document.getElementById("box");
// let lSide3 = 100;
// let tSide3 = 100;

// window.addEventListener("keydown",(e)=> {
//     let move =50;
//     switch(e.key){
//         case "w":
//             tSide =tSide-move;
//             break;
//         case "s":
//             tSide =tSide-move;
//             break;
//         case "a":
//             tSide =tSide-move;
//             break;
//         case "d":
//             tSide =tSide-move;
//             break;
//         default:
//             break;
//     }
//     box.style.left=lSide+"px"
//     box.style.top=tSide+"px"

// })

alert("Javascript is working properly!!")

const btn1 = document.getElementById("btn1");

let windowName;

btn1.addEventListener("click",()=>{
    windowName = window.open("https://www.google.com/","width=600,height=800");
})

const btn2 = document.getElementById("btn2")

