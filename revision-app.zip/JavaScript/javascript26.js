var num = 26;
let num2 = 27;
const num3 = 31;












