var gf = "Kirti";
console.log(gf);

var gf = "Anamika";
console.log(gf);


let gff = "Priti";
console.log(gff);


gff = "Priya";
console.log(gff);


const gfff = "Prerna";
console.log(gfff);

gfff = "Lilavati";
console.log(gfff);








console.log();
console.log();











